@echo off

cd %~dp0/bin
python launch.py

if errorlevel 2 (
    python firststart.py
    python -c "import twitchio" >nul 2>&1
    if errorlevel 1 (
        echo twitchio not found. Installing...
        python -m pip install -U twitchio==3.1.0
    )
    
    python -c "import asqlite" >nul 2>&1
    if errorlevel 1 (
        echo asqlite not found. Installing...
        python -m pip install -U git+https://github.com/Rapptz/asqlite.git
    )
    
    python -c "import obsws_python" >nul 2>&1
    if errorlevel 1 (
        echo obsws_python not found. Installing...
        python -m pip install -U obsws-python
    )

    python -c "import keyboard" >nul 2>&1
    if errorlevel 1 (
        echo keyboard not found. Installing...
        python -m pip install -U keyboard
    )
    
    python -c "import tomli_w" >nul 2>&1
    if errorlevel 1 (
        echo tomli_w not found. Installing...
        python -m pip install -U tomli_w
    )
    python firststartsetup.py
)

if errorlevel 1 (
    python -c "import twitchio" >nul 2>&1
    if errorlevel 1 (
        echo twitchio not found. Installing...
        python -m pip install -U twitchio==3.1.0
    )
    
    python -c "import asqlite" >nul 2>&1
    if errorlevel 1 (
        echo asqlite not found. Installing...
        python -m pip install -U git+https://github.com/Rapptz/asqlite.git
    )
    
    python -c "import obsws_python" >nul 2>&1
    if errorlevel 1 (
        echo obsws_python not found. Installing...
        python -m pip install -U obsws-python
    )

    python -c "import keyboard" >nul 2>&1
    if errorlevel 1 (
        echo keyboard not found. Installing...
        python -m pip install -U keyboard
    )
    
    python -c "import tomli_w" >nul 2>&1
    if errorlevel 1 (
        echo tomli_w not found. Installing...
        python -m pip install -U tomli_w
    )

)

cd %~dp0/bin
python main.py
pause

